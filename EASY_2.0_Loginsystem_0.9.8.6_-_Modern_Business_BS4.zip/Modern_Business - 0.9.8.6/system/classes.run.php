<?php
/********************************************
*
* System:   EASY 2.0 Loginsystem
* Author:   Marius Rasche (aka Marlight)
* Class:    database
* FVersion: 1.4 (this file)
* SVersion: 0.9.8.5 (complete System)
* Date:     04.04.2023
*
* Created by www.marlight-systems.de
* Copyright by Marlight Systems (www.marlight-systems.de)
* All rights reserved.
*
*********************************************/

define('DEMO_MODE', false);

// Autoloader for Class-Files
spl_autoload_register(static function($class){
    $dir = str_replace('\\', '/', $class);
    if(substr($dir, -1) === 'I'){ // If an interface?
        $path = explode('/', $dir);
        $lastElement = array_pop($path);
        $dir = implode('/', $path).'/Interfaces/'.$lastElement;
    }
    require_once 'system/classes/'.$dir.'.php';
});


// Initialize the Loginsystem
$loginsystem = new loginsystem();

// Initialize Captcha
if(isset($_GET['captcha']) && $_GET['captcha'] == 'img'){
	$captcha = new captcha();
	$captcha->generateCaptcha();
}

// Initialize Rules
if(isset($_GET['p']) && $_GET['p'] == 'rules'){
	$rules = new rules();
}

// Initialize Sites
$sites = new sites();

// Initialize Menu
$menu = new menu();

// Initialize additional fields
$additional_fields = new additional_fields();



