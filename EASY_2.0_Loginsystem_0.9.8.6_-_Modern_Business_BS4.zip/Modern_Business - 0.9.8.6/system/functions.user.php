<?php
/******************
 *
 * Eigene Funktionen
 *
 ******************/







